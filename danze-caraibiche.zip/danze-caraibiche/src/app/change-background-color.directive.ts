import { Directive, OnInit, HostBinding, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[appChangeBackgroundColor]'
})
export class ChangeBackgroundColorDirective implements OnInit {
  @Input() firstColor: string = 'transparent';
  @Input('appChangeBackgroundColor') colorOver: string = 'blue';
  @HostBinding('style.backgroundColor') backgroundColor: string;

  constructor() {
  }

  ngOnInit() {
    this.backgroundColor = this.firstColor;
  }

  @HostListener('mouseenter') mouseover(eventData: Event) {
    this.backgroundColor = this.colorOver;
  }

  @HostListener('mouseleave') mouseleave(eventData: Event) {
    this.backgroundColor = this.firstColor;
  }
}
