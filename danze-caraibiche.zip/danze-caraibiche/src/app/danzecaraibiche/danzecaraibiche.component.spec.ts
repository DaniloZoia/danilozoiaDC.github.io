import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DanzecaraibicheComponent } from './danzecaraibiche.component';

describe('DanzecaraibicheComponent', () => {
  let component: DanzecaraibicheComponent;
  let fixture: ComponentFixture<DanzecaraibicheComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DanzecaraibicheComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DanzecaraibicheComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
