import { Component, OnInit, NgModule } from '@angular/core';
import { MatDialog } from '@angular/material';
import { FirstService } from '../first.service';

@Component({
  selector: 'app-danzecaraibiche',
  templateUrl: './danzecaraibiche.component.html',
  styleUrls: ['./danzecaraibiche.component.css'],
  providers: [FirstService]
})
export class DanzecaraibicheComponent implements OnInit {

  titleTwo = this.firstService.getTitleTwo();
  dance = 4;
  switchDefault = true;

  constructor(private firstService: FirstService, public dialog: MatDialog) { }

  openDialog() {

    this.dialog.open(DialogModal);

  }

  ngOnInit() {
  }

}

@Component({
  selector: 'dialog-modal',
  templateUrl: '../dialog-modal.html'
})
@NgModule({
  imports: [],
  declarations: [],
  exports: [],
  providers: [],
})
export class DialogModal { }
