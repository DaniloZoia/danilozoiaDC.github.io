import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { DanzecaraibicheComponent, DialogModal } from './danzecaraibiche/danzecaraibiche.component';
import { InizioComponent } from './inizio/inizio.component';
import { FormComponent } from './form/form.component';
import { EsitoFormComponent } from './esito-form/esito-form.component';
import { ReactiveFormsModule, FormsModule } from "@angular/forms";
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';
import { AngularFireModule } from '@angular/fire';
import { AngularFirestoreModule } from '@angular/fire/firestore';
import { AngularFireAuthModule } from '@angular/fire/auth';
import { environment } from 'src/environments/environment';
import { ServiceWorkerModule } from '@angular/service-worker';
import { AlertsModule } from 'angular-alert-module';
import { MatDialogModule } from '@angular/material';
import { MatButtonModule } from '@angular/material/button';
import { BrowserAnimationsModule, NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ScrollTopComponent } from './scroll-top/scroll-top.component';
import { ChangeColorDirective } from './change-color.directive';
import { ChangeBackgroundColorDirective } from './change-background-color.directive';
import { AppRoutingModule } from './app-routing.module';

@NgModule({
  declarations: [
    AppComponent,
    InizioComponent,
    DanzecaraibicheComponent,
    FormComponent,
    EsitoFormComponent,
    ReactiveFormComponent,
    DialogModal,
    ScrollTopComponent,
    ChangeColorDirective,
    ChangeBackgroundColorDirective
  ],
  imports: [
    AngularFireModule.initializeApp(environment.firebase),
    AngularFirestoreModule,
    AngularFireAuthModule,
    AppRoutingModule,
    BrowserModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production }),
    ReactiveFormsModule.withConfig({ warnOnNgModelWithFormControl: 'never' }),
    AlertsModule.forRoot(),
    MatDialogModule,
    MatButtonModule,
    DialogModal,
    BrowserAnimationsModule,
    NoopAnimationsModule
  ],
  entryComponents: [DialogModal],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
