import { Component, OnInit } from '@angular/core';
import { AlertsService } from 'angular-alert-module';

@Component({
  selector: 'app-inizio',
  templateUrl: './inizio.component.html',
  styleUrls: ['./inizio.component.css'],
})
export class InizioComponent implements OnInit {

  titleOne = 'Balli di coppia';
  valueFw = true;

  constructor(private alerts: AlertsService) { }

  ngOnInit() {
    // per sessione e non per utente (client)
    // var cookie = sessionStorage['cookie']
    var cookie = localStorage.getItem('cookie') || ''
    if (cookie != 'existing!') {
      this.alerts.setMessage('Questo sito fa uso di cookie per migliorare l’esperienza di navigazione degli utenti e per raccogliere informazioni sull’utilizzo del sito stesso. Proseguendo nella navigazione si accetta l’uso dei cookie, in caso contrario è possibile abbandonare il sito.', 'alert');
      this.alerts.setDefaults('timeout', 11);
      this.alerts.setConfig('alert', 'icon', 'notification_important');
      localStorage.setItem('cookie', 'existing!')
    // per sessione e non per utente (client)
    // sessionStorage['cookie'] = 'existing!';
    }
  }

}
