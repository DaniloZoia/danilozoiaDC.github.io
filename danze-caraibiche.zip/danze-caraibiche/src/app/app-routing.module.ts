import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InizioComponent } from './inizio/inizio.component';
import { DanzecaraibicheComponent } from './danzecaraibiche/danzecaraibiche.component';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';
import { EsitoFormComponent } from './esito-form/esito-form.component';

const compRoutes: Routes = [
  { path: '', component: InizioComponent },
  { path: 'danzeCaraibiche', component: DanzecaraibicheComponent },
  { path: 'form', component: ReactiveFormComponent },
  { path: 'esitoForm', component: EsitoFormComponent },
];

@NgModule({
  imports: [
    RouterModule.forRoot(compRoutes,
      { enableTracing: true }),
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
