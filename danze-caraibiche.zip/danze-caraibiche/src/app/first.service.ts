import { Injectable } from '@angular/core';

@Injectable()
export class FirstService {
  private titleTwo = 'Danze caraibiche';

  getTitleTwo() {
    return this.titleTwo;
  }
}
