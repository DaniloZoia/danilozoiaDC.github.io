import { Component, OnInit } from '@angular/core';
import { RouterModule, Router } from '@angular/router';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})

export class FormComponent implements OnInit {

  constructor(private router: Router) { }

  goResponse() {
    this.router.navigate(['esitoForm']);
  }

  ngOnInit() {
  }
}
