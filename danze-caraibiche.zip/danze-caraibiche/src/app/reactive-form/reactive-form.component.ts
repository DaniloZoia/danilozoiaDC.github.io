import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Model } from '../model';
import { AngularFirestoreCollection, AngularFirestore } from '@angular/fire/firestore';
import { AngularFireAuth } from '@angular/fire/auth';
import { auth } from 'firebase';

@Component({
  selector: 'app-reactive-form',
  templateUrl: './reactive-form.component.html',
  styleUrls: ['./reactive-form.component.css']
})

export class ReactiveFormComponent implements OnInit {

  reactiveForm: FormGroup;
  item: Model = {};
  modelCollection: AngularFirestoreCollection<any>;
  value = true;

  constructor(private router: Router, private fb: FormBuilder, private afs: AngularFirestore, private afAuth: AngularFireAuth) {

    this.reactiveForm = this.fb.group({
      txtNome: ['', [Validators.required, Validators.minLength(2)]],
      txtCognome: ['', [Validators.required, Validators.maxLength(30)]],
      txtEmail: ['', [Validators.required, Validators.maxLength(20)]],
      numGradimentocaraibiche: ['', [Validators.required]],
      numGradimentolatinoamericane: ['', [Validators.required]],
      txtCommenti: ['', [Validators.required]]
    });

    this.modelCollection = this.afs.collection<Model>('model');

  }

  onSubmit() {

    //console.warn(this.reactiveForm.value);
    
    this.afAuth.auth.signInWithPopup(new auth.GoogleAuthProvider()).then((credential: auth.UserCredential) => {
      console.log(credential.user.email);
    });

    setTimeout(() => {
    this.modelCollection.add(this.item);
      this.item = {};
    }, 23000);

    setTimeout(() => {
      this.router.navigate(['esitoForm']);
    }, 26000);

    this.value = !this.value;

  }

  ngOnInit() {
  }

}
