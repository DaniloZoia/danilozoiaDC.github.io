import { Directive, OnInit, HostBinding, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[appChangeColor]'
})

export class ChangeColorDirective implements OnInit {
  @Input() initialColor: string = 'transparent';
  @Input('appChangeColor') colorHover: string = 'cyan';
  @HostBinding('style.color') fontColor: string;

  constructor() { }

  ngOnInit() {
    this.fontColor = this.initialColor;
  }

  @HostListener('mouseenter') mouseover(eventData: Event) {
    this.fontColor = this.colorHover;
  }

  @HostListener('mouseleave') mouseleave(eventData: Event) {
    this.fontColor = this.initialColor;
  }

}
