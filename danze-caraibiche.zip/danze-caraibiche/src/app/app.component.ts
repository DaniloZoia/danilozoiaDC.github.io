import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {

  ham: any;

  constructor() { }

  myHamburger() {
    this.ham = document.getElementById("myMenu");
    if (this.ham.className === "menu") {
      this.ham.className += " responsive";
    } else {
      this.ham.className = "menu";
    }
  }

}
