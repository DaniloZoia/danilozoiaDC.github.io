export interface Model {

  nome?: string;
  cognome?: string;
  email?: string;
  gradimentocaraibiche?: number;
  gradimentolatinoamericane?: number;
  commenti?: string;

}
