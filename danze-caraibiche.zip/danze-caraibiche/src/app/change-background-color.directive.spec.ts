import { ChangeBackgroundColorDirective } from './change-background-color.directive';

describe('ChangeBackgroundColorDirective', () => {
  it('should create an instance', () => {
    const directive = new ChangeBackgroundColorDirective();
    expect(directive).toBeTruthy();
  });
});
