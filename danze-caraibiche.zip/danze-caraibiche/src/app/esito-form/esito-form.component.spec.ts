import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EsitoFormComponent } from './esito-form.component';

describe('EsitoFormComponent', () => {
  let component: EsitoFormComponent;
  let fixture: ComponentFixture<EsitoFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EsitoFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EsitoFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
