import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-esito-form',
  templateUrl: './esito-form.component.html',
  styleUrls: ['./esito-form.component.css']
})

export class EsitoFormComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}
